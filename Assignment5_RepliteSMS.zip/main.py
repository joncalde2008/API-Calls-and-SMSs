from flask import Flask, render_template, redirect, url_for, flash
from twilio.rest import Client
from space import people_space
import random
from weather import get_weather
from hp import get_char
import json
import os

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY')

# Define route to display form
@app.route('/')
def index():
    return render_template('index.html')

# Define route to process form submission
@app.route('/send_messages', methods=['POST'])
def send_messages():
    account_sid = os.environ['MY_TWILIO_ACCOUNT_SID']
    auth_token = os.environ['MY_TWILIO_AUTH_TOKEN']
    client = Client(account_sid, auth_token)

    student = {
        "Jonathan": {
            "name": "Jonathan",
            "number": "+12499795197",
            "lucky_number": random.randint(1, 100),
            "location": "madrid"
        }        
    }

    for key, value in student.items():
        char_info = get_char()  # Get character information including the image link
        msg = (
            f'{value["name"].title()} your lucky number is {value["lucky_number"]} '
            f'and your phone number is {value["number"]} and space {people_space()} '
            f'and the your city is {value["location"]} with the temperature '
            f'{get_weather(value["location"])} , Random HP character {char_info}'
        )

        message = client.messages \
                        .create(
                             body=msg,
                             from_='+17637103387', #this is your virtual twilio number
                             to=value['number'] # this is the cellular number - Canada number
                         )

        print(message.sid)
        print(msg)

        with open('message.json', 'a') as outfile:  # saving in json
            json.dump(msg, outfile)
            outfile.write('\n')  # Add a newline to separate JSON objects

    # Set a variable to indicate that the message has been sent
    message_sent = True

    # Render the template with the message_sent variable
    return render_template('index.html', message_sent=message_sent)

if __name__ == '__main__':
    app.run(debug=True)

