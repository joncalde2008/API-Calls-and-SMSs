import urllib.request
import json

def get_weather(city):
  key = 'ae75b36c9870975b59363bcc0e4fa568'
  url = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={key}'

  request = urllib.request.urlopen(url)
  result = json.loads(request.read())

  #print(result)
  return (round(result["main"]["temp"]-273.15,2))