
import urllib.request
import json 


def people_space():
  url = 'http://api.open-notify.org/astros.json'
  request= urllib.request.urlopen(url)
  result = json.loads(request.read())

  #print(result)
  return f"The number of people in space is {result['number']}"